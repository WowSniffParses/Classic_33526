# TrinityCore - WowPacketParser
# File name: TRY1_MAGE_POSITION_(1.13.3.33526)-17452.pkt
# Detected build: V1_13_3_33526
# Detected locale: enUS
# Targeted database: Classic
# Parsing date: 03/14/2021 11:31:21

SET @ACCID = 0; 
SET @CGUID = 0; 
SET @DGUID = 0;
SET @IGUID = 0; 
SET @OGUID = 0; 
SET @PGUID = 0; 
SET @POIID = 0; 
SET @LOOTID = 0; 
SET @SNIFFID = 0; 

DELETE FROM `player` WHERE `guid` BETWEEN @PGUID+0 AND @PGUID+3;
INSERT INTO `player` (`guid`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `name`, `race`, `class`, `gender`, `level`, `xp`, `money`, `player_bytes1`, `player_bytes2`, `player_flags`, `pvp_rank`, `scale`, `display_id`, `native_display_id`, `mount_display_id`, `faction`, `unit_flags`, `unit_flags2`, `current_health`, `max_health`, `current_mana`, `max_mana`, `aura_state`, `emote_state`, `stand_state`, `vis_flags`, `sheath_state`, `pvp_flags`, `shapeshift_form`, `move_flags`, `speed_walk`, `speed_run`, `speed_run_back`, `speed_swim`, `speed_swim_back`, `speed_fly`, `speed_fly_back`, `bounding_radius`, `combat_reach`, `mod_melee_haste`, `main_hand_attack_time`, `off_hand_attack_time`, `ranged_attack_time`, `channel_spell_id`, `channel_visual_id`, `equipment_cache`, `auras`) VALUES
(@PGUID+3, 0, -10567.95, 987.7937, 41.08836, 6.10492, 'Cjvufhft', 4, 11, 0, 25, 0, 0, 84280835, 16777216, 2, 0, 1, 892, 55, 0, 4, 8, 2048, 100, 100, 904, 904, 4194304, 0, 1, 0, 0, 0, 1, 0, 1, 1.3, 1, 1, 1, 1, 1, 0.9, 1.35, 1, 1000, 1000, 2000, 0, 0, '3392 0 0 0 7415 0 0 0 14562 0 15347 0 4831 0 10402 0 12999 0 15125 0 11993 0 1076 0 0 0 0 0 15519 0 4575 0 0 0 0 0 0 0', '768 24868 24864 24900 20583 20582 21009 16938 16941 16931 7503 7479 7465 9098 7490 7491 7503 7478 7466 7507 7502 3025 24866 16944'),
(@PGUID+1, 0, -10649.57, 1037.999, 33.54599, 1.948949, 'Kdnrxlal', 7, 8, 0, 18, 877, 35408, 263168, 67108864, 0, 0, 1, 1563, 1563, 0, 115, 8, 2048, 347, 347, 1086, 1086, 0, 0, 0, 0, 0, 0, 0, 2048, 1, 1, 1, 1, 1, 1, 1, 0.3519, 1.725, 1, 3000, 2000, 1300, 0, 0, '0 0 0 0 14170 0 6096 0 6528 0 14173 0 6540 0 14174 0 14166 0 5195 0 1156 0 0 0 0 0 0 0 6378 0 5201 0 0 0 5198 0 0 0', '20592'),
(@PGUID+2, 0, -10716.21, 1102.81, 49.28538, 2.208645, 'Vbvjjqbo', 3, 2, 0, 15, 0, 0, 33882624, 100663296, 0, 0, 1, 53, 53, 0, 3, 8, 2048, 100, 100, 452, 452, 4194304, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0.347, 1.5, 1, 3000, 2000, 2000, 0, 0, '0 0 0 0 0 0 6117 0 6085 0 1154 0 3473 0 3469 0 6177 0 2547 0 0 0 0 0 0 0 0 0 3511 0 3192 0 0 0 0 0 0 0', '10290 2580 5232 1244 20595 20596 20105 25956 7471 7465');

DELETE FROM `player_guid_values` WHERE `guid` BETWEEN @PGUID+0 AND @PGUID+3;
INSERT INTO `player_guid_values` (`guid`, `charm_guid`, `charm_id`, `charm_type`, `summon_guid`, `summon_id`, `summon_type`, `charmer_guid`, `charmer_id`, `charmer_type`, `summoner_guid`, `summoner_id`, `summoner_type`, `creator_guid`, `creator_id`, `creator_type`, `demon_creator_guid`, `demon_creator_id`, `demon_creator_type`, `target_guid`, `target_id`, `target_type`) VALUES
(@PGUID+3, 0, 0, '', 0, 0, '', 0, 0, '', 0, 0, '', 0, 0, '', 0, 0, '', 0, 8723, 'Creature');

DELETE FROM `player_active_player` WHERE (`unixtime`=1583281819 AND `guid`='@PGUID+1');
INSERT INTO `player_active_player` (`unixtime`, `guid`) VALUES
(1583281819, @PGUID+1);

INSERT INTO `player_create1_time` (`unixtimems`, `guid`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) VALUES
(1583281819984, @PGUID+3, 0, -10567.95, 987.7937, 41.08836, 6.10492),
(1583281819984, @PGUID+2, 0, -10716.21, 1102.81, 49.28538, 2.208645);

INSERT INTO `player_create2_time` (`unixtimems`, `guid`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) VALUES
(1583281819984, @PGUID+1, 0, -10649.57, 1037.999, 33.54599, 1.948949);

INSERT INTO `player_destroy_time` (`unixtimems`, `guid`) VALUES
(1583281822312, @PGUID+2);

INSERT INTO `player_movement_client` (`unixtimems`, `guid`, `opcode`, `move_time`, `move_flags`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) VALUES
(1583281819984, @PGUID+2, 'SMSG_MOVE_UPDATE', 2733855473, 1, 0, -10718.21, 1105.445, 49.47318, 2.243552),
(1583281820203, @PGUID+2, 'SMSG_MOVE_UPDATE', 2733855575, 1, 0, -10718.67, 1105.991, 49.49694, 2.344781),
(1583281820343, @PGUID+1, 'CMSG_MOVE_FALL_LAND', 1073800560, 0, 0, -10649.57, 1037.999, 33.54599, 1.948949),
(1583281820359, @PGUID+1, 'CMSG_MOVE_SPLINE_DONE', 1073800696, 2048, 0, -10649.57, 1037.999, 33.54599, 1.948949),
(1583281820359, @PGUID+2, 'SMSG_MOVE_UPDATE', 2733855767, 1, 0, -10719.65, 1106.912, 49.54498, 2.446011),
(1583281820500, @PGUID+2, 'SMSG_MOVE_UPDATE', 2733855994, 1, 0, -10720.92, 1107.868, 49.5873, 2.540259),
(1583281821125, @PGUID+2, 'SMSG_MOVE_UPDATE', 2733856494, 1, 0, -10723.8, 1109.845, 49.57927, 2.540259),
(1583281821609, @PGUID+2, 'SMSG_MOVE_UPDATE', 2733856994, 1, 0, -10726.69, 1111.825, 49.54281, 2.540259),
(1583281822109, @PGUID+2, 'SMSG_MOVE_UPDATE', 2733857494, 1, 0, -10729.58, 1113.805, 49.33377, 2.540259);

INSERT INTO `player_movement_server` (`unixtimems`, `guid`, `point`, `move_time`, `spline_flags`, `spline_count`, `start_position_x`, `start_position_y`, `start_position_z`, `end_position_x`, `end_position_y`, `end_position_z`, `orientation`) VALUES
(1583281820203, @PGUID+1, 1, 0, 0, 0, -10649.57, 1037.999, 33.54599, 0, 0, 0, 100);


INSERT INTO `player_auras_update` (`unixtimems`, `guid`, `update_id`, `slot`, `spell_id`, `visual_id`, `aura_flags`, `active_flags`, `level`, `charges`, `duration`, `max_duration`, `caster_guid`, `caster_id`, `caster_type`) VALUES
(1583281819984, @PGUID+3, 1, 1, 768, 237313, 3, 7, 25, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 2, 24868, 0, 3, 1, 25, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 3, 24864, 0, 3, 1, 25, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 4, 24900, 0, 3, 1, 25, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 48, 20583, 0, 1, 1, 25, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 49, 20582, 0, 1, 1, 25, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 50, 21009, 0, 1, 1, 25, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 51, 16938, 0, 1, 3, 25, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 52, 16941, 0, 1, 1, 25, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 53, 16931, 0, 1, 1, 25, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 54, 7503, 0, 1, 1, 28, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 55, 7479, 0, 1, 1, 23, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 56, 7465, 0, 1, 1, 23, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 57, 9098, 0, 1, 1, 29, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 58, 7490, 0, 1, 1, 19, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 59, 7491, 0, 1, 1, 29, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 60, 7503, 0, 1, 1, 29, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 61, 7478, 0, 1, 1, 22, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 62, 7466, 0, 1, 1, 22, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 63, 7507, 0, 1, 1, 28, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 64, 7502, 0, 1, 1, 19, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 65, 3025, 0, 1, 3, 25, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 66, 24866, 0, 1, 1, 25, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+3, 1, 67, 16944, 0, 1, 1, 25, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+1, 1, 48, 20592, 0, 1, 1, 18, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+1, 2, 49, 20593, 0, 1, 1, 18, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+1, 3, 50, 20591, 0, 1, 1, 18, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+1, 4, 51, 7778, 0, 1, 1, 19, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+1, 5, 52, 7470, 0, 1, 1, 19, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+1, 6, 53, 7850, 0, 1, 1, 17, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+1, 7, 54, 7470, 0, 1, 1, 18, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+1, 8, 55, 7479, 0, 1, 1, 18, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+1, 9, 56, 7470, 0, 1, 1, 20, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+1, 10, 57, 7479, 0, 1, 1, 20, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+1, 11, 58, 13363, 0, 1, 1, 23, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+1, 12, 59, 7455, 0, 1, 1, 19, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+1, 13, 60, 7470, 0, 1, 1, 19, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+1, 14, 61, 7475, 0, 1, 1, 19, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+2, 1, 0, 10290, 243616, 3, 1, 15, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+2, 1, 4, 2580, 0, 3, 1, 15, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+2, 1, 5, 5232, 240050, 6, 3, 17, 0, 0, 0, 0, 0, 'Player'),
(1583281819984, @PGUID+2, 1, 6, 1244, 237220, 6, 1, 18, 0, 0, 0, 0, 0, 'Player'),
(1583281819984, @PGUID+2, 1, 48, 20595, 0, 1, 1, 15, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+2, 1, 49, 20596, 0, 1, 1, 15, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+2, 1, 50, 20105, 0, 1, 1, 15, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+2, 1, 51, 25956, 0, 1, 1, 15, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+2, 1, 52, 7471, 0, 1, 1, 12, 0, 0, 0, 0, 0, ''),
(1583281819984, @PGUID+2, 1, 53, 7465, 0, 1, 1, 12, 0, 0, 0, 0, 0, '');

INSERT INTO `player_values_update` (`unixtimems`, `guid`, `entry`, `scale`, `display_id`, `mount_display_id`, `faction`, `level`, `npc_flags`, `unit_flags`, `unit_flags2`, `dynamic_flags`, `current_health`, `max_health`, `current_mana`, `max_mana`, `aura_state`, `emote_state`, `stand_state`, `vis_flags`, `sheath_state`, `pvp_flags`, `shapeshift_form`, `bounding_radius`, `combat_reach`, `mod_melee_haste`, `main_hand_attack_time`, `off_hand_attack_time`, `channel_spell_id`, `channel_visual_id`) VALUES
(1583281819984, @PGUID+1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 372, 442, NULL, 1371, 4194304, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1583281821500, @PGUID+1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 380, NULL, 1112, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1583281823515, @PGUID+1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 388, NULL, 1139, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1583281825531, @PGUID+1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 396, NULL, 1166, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1583281827562, @PGUID+1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 404, NULL, 1193, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1583281829578, @PGUID+1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 412, NULL, 1219, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);


INSERT IGNORE INTO `weather_update` (`unixtimems`, `map_id`, `zone_id`, `weather_state`, `grade`, `instant`) VALUES
(1583281819437, 0, 40, 1, 0, 1); -- 0 - Fog - 0

DELETE FROM `world_state_init` WHERE (`unixtimems`=1583281819375 AND `map`=0 AND `zone_id`=40 AND `area_id`=108 AND `variable`=17648 AND `value`=0) OR (`unixtimems`=1583281819375 AND `map`=0 AND `zone_id`=40 AND `area_id`=108 AND `variable`=17647 AND `value`=0) OR (`unixtimems`=1583281819375 AND `map`=0 AND `zone_id`=40 AND `area_id`=108 AND `variable`=17223 AND `value`=1) OR (`unixtimems`=1583281819375 AND `map`=0 AND `zone_id`=40 AND `area_id`=108 AND `variable`=2264 AND `value`=0) OR (`unixtimems`=1583281819375 AND `map`=0 AND `zone_id`=40 AND `area_id`=108 AND `variable`=2263 AND `value`=0) OR (`unixtimems`=1583281819375 AND `map`=0 AND `zone_id`=40 AND `area_id`=108 AND `variable`=2262 AND `value`=0) OR (`unixtimems`=1583281819375 AND `map`=0 AND `zone_id`=40 AND `area_id`=108 AND `variable`=2261 AND `value`=0) OR (`unixtimems`=1583281819375 AND `map`=0 AND `zone_id`=40 AND `area_id`=108 AND `variable`=2260 AND `value`=0) OR (`unixtimems`=1583281819375 AND `map`=0 AND `zone_id`=40 AND `area_id`=108 AND `variable`=2259 AND `value`=0);
INSERT INTO `world_state_init` (`unixtimems`, `map`, `zone_id`, `area_id`, `variable`, `value`) VALUES
(1583281819375, 0, 40, 108, 17648, 0),
(1583281819375, 0, 40, 108, 17647, 0),
(1583281819375, 0, 40, 108, 17223, 1),
(1583281819375, 0, 40, 108, 2264, 0),
(1583281819375, 0, 40, 108, 2263, 0),
(1583281819375, 0, 40, 108, 2262, 0),
(1583281819375, 0, 40, 108, 2261, 0),
(1583281819375, 0, 40, 108, 2260, 0),
(1583281819375, 0, 40, 108, 2259, 0);


DELETE FROM `creature` WHERE `guid` BETWEEN @CGUID+0 AND @CGUID+13;
INSERT INTO `creature` (`guid`, `id`, `map`, `zone_id`, `area_id`, `position_x`, `position_y`, `position_z`, `orientation`, `wander_distance`, `movement_type`, `is_spawn`, `is_hovering`, `is_temporary`, `is_pet`, `summon_spell`, `scale`, `display_id`, `native_display_id`, `mount_display_id`, `class`, `gender`, `faction`, `level`, `npc_flags`, `unit_flags`, `unit_flags2`, `dynamic_flags`, `current_health`, `max_health`, `current_mana`, `max_mana`, `aura_state`, `emote_state`, `stand_state`, `vis_flags`, `sheath_state`, `pvp_flags`, `shapeshift_form`, `move_flags`, `speed_walk`, `speed_run`, `speed_run_back`, `speed_swim`, `speed_swim_back`, `speed_fly`, `speed_fly_back`, `bounding_radius`, `combat_reach`, `mod_melee_haste`, `main_hand_attack_time`, `off_hand_attack_time`, `main_hand_slot_item`, `off_hand_slot_item`, `ranged_slot_item`, `channel_spell_id`, `channel_visual_id`, `auras`, `sniff_build`) VALUES
(@CGUID+11, 878, 0, 40, 108, -10636.27, 1127.258, 33.87674, 5.916666, 0, 0, 0, 0, 0, 0, 0, 1, 2373, 2373, 0, 1, 0, 12, 30, 2, 512, 2048, 0, 1003, 1003, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', 33526),
(@CGUID+6, 876, 0, 40, 108, -10641.65, 1093.465, 34.04298, 4.747295, 0, 0, 0, 0, 0, 0, 0, 1, 2370, 2370, 0, 1, 0, 11, 30, 0, 0, 2048, 0, 1910, 1910, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 1896, 2052, 0, 0, 0, '', 33526),
(@CGUID+5, 870, 0, 40, 108, -10657.45, 1090.456, 34.49815, 5.340707, 0, 0, 0, 0, 0, 0, 0, 1, 2365, 2365, 0, 1, 1, 11, 30, 0, 0, 2048, 0, 1910, 1910, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.208, 1.5, 1, 2000, 2000, 1897, 2053, 0, 0, 0, '', 33526),
(@CGUID+9, 842, 0, 40, 108, -10658.95, 1124.188, 34.19674, 5.532178, 0, 0, 0, 0, 0, 0, 0, 1, 89, 308, 0, 1, 0, 12, 5, 0, 0, 2048, 0, 102, 102, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 1, 1, 1, 2000, 2000, 1909, 0, 0, 0, 0, '9127', 33526),
(@CGUID+12, 6670, 0, 40, 108, -10653.21, 1130.438, 34.19574, 2.494652, 0, 0, 0, 0, 0, 0, 0, 1, 3264, 3264, 0, 1, 0, 12, 5, 0, 0, 2048, 0, 102, 102, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 1902, 0, 0, 0, 0, '', 33526),
(@CGUID+7, 6670, 0, 40, 108, -10646.26, 1113.476, 35.64552, 0.8901179, 0, 0, 0, 0, 0, 0, 0, 1, 3264, 3264, 0, 1, 0, 12, 5, 0, 0, 2048, 0, 102, 102, 0, 0, 0, 69, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 1902, 0, 0, 0, 0, '', 33526),
(@CGUID+2, 843, 0, 40, 108, -10661.21, 999.3558, 32.95747, 0.6283185, 0, 0, 0, 0, 0, 0, 0, 1, 3260, 3260, 0, 1, 1, 12, 15, 128, 512, 2048, 0, 328, 328, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.208, 1.5, 1, 1500, 1500, 1906, 0, 0, 0, 0, '', 33526),
(@CGUID+8, 6670, 0, 40, 108, -10661.11, 1115.039, 34.19674, 1.632294, 15.81844, 1, 0, 0, 0, 0, 0, 1, 3264, 3264, 0, 1, 0, 12, 5, 0, 0, 2048, 0, 102, 102, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 1902, 0, 0, 0, 0, '', 33526), --  (possible waypoints or random movement)
(@CGUID+4, 1670, 0, 40, 108, -10653.26, 995.3947, 32.95747, 1.605703, 0, 0, 0, 0, 0, 0, 0, 1, 3262, 3262, 0, 1, 0, 12, 20, 128, 512, 2048, 0, 484, 484, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 1500, 1500, 1907, 0, 0, 0, 0, '', 33526),
(@CGUID+3, 1668, 0, 40, 108, -10658.53, 996.8511, 32.95747, 0.8726646, 0, 0, 0, 0, 0, 0, 0, 1, 3259, 3259, 0, 1, 0, 12, 15, 4224, 512, 2048, 0, 328, 328, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 1500, 1500, 0, 0, 5260, 0, 0, '', 33526),
(@CGUID+10, 6670, 0, 40, 108, -10656.16, 1126.872, 34.19674, 5.602507, 0, 0, 0, 0, 0, 0, 0, 1, 3264, 3264, 0, 1, 0, 12, 5, 0, 0, 2048, 0, 102, 102, 0, 0, 0, 69, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 1902, 0, 0, 0, 0, '', 33526),
(@CGUID+1, 523, 0, 40, 108, -10628.32, 1037.265, 34.1915, 2.286381, 0, 0, 0, 0, 0, 0, 0, 1, 3263, 3263, 0, 1, 0, 12, 55, 8195, 512, 2048, 0, 7842, 7842, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1.142857, 1, 1, 1, 1, 1, 0.306, 1.5, 1, 2000, 2000, 0, 0, 0, 0, 0, '', 33526),
(@CGUID+13, 547, 0, 40, 108, -10600.92, 951.6986, 38.54507, 1.645096, 8.986684, 1, 0, 0, 0, 0, 0, 1, 3035, 3035, 0, 1, 2, 189, 16, 0, 0, 2048, 0, 356, 356, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1.142857, 1, 1, 1, 1, 1, 1.3524, 1.15, 1, 2000, 2000, 0, 0, 0, 0, 0, '', 33526); --  (possible waypoints or random movement)

INSERT INTO `creature_create1_time` (`unixtimems`, `guid`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) VALUES
(1583281819984, @CGUID+11, 0, -10636.27, 1127.258, 33.87674, 5.916666),
(1583281819984, @CGUID+6, 0, -10641.65, 1093.465, 34.04298, 4.747295),
(1583281819984, @CGUID+5, 0, -10657.45, 1090.456, 34.49815, 5.340707),
(1583281819984, @CGUID+9, 0, -10658.95, 1124.188, 34.19674, 5.532178),
(1583281819984, @CGUID+12, 0, -10653.21, 1130.438, 34.19574, 2.494652),
(1583281819984, @CGUID+7, 0, -10646.26, 1113.476, 35.64552, 0.8901179),
(1583281819984, @CGUID+2, 0, -10661.21, 999.3558, 32.95747, 0.6283185),
(1583281819984, @CGUID+8, 0, -10661.11, 1115.039, 34.19674, 1.632294),
(1583281819984, @CGUID+4, 0, -10653.26, 995.3947, 32.95747, 1.605703),
(1583281819984, @CGUID+3, 0, -10658.53, 996.8511, 32.95747, 0.8726646),
(1583281819984, @CGUID+10, 0, -10656.16, 1126.872, 34.19674, 5.602507),
(1583281819984, @CGUID+1, 0, -10628.32, 1037.265, 34.1915, 2.286381),
(1583281825250, @CGUID+13, 0, -10600.92, 951.6986, 38.54507, 1.645096);

INSERT INTO `creature_auras_update` (`unixtimems`, `guid`, `update_id`, `slot`, `spell_id`, `visual_id`, `aura_flags`, `active_flags`, `level`, `charges`, `duration`, `max_duration`, `caster_guid`, `caster_id`, `caster_type`) VALUES
(1583281819984, @CGUID+9, 1, 0, 9127, 0, 3, 1, 5, 0, 0, 0, 0, 0, ''),
(1583281828359, @CGUID+9, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');

INSERT INTO `creature_values_update` (`unixtimems`, `guid`, `entry`, `scale`, `display_id`, `mount_display_id`, `faction`, `level`, `npc_flags`, `unit_flags`, `unit_flags2`, `dynamic_flags`, `current_health`, `max_health`, `current_mana`, `max_mana`, `aura_state`, `emote_state`, `stand_state`, `vis_flags`, `sheath_state`, `pvp_flags`, `shapeshift_form`, `bounding_radius`, `combat_reach`, `mod_melee_haste`, `main_hand_attack_time`, `off_hand_attack_time`, `channel_spell_id`, `channel_visual_id`) VALUES
(1583281828359, @CGUID+9, NULL, NULL, 308, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.306, 1.5, NULL, NULL, NULL, NULL, NULL),
(1583281825937, @CGUID+12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 69, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(1583281828781, @CGUID+7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

INSERT INTO `creature_speed_update` (`unixtimems`, `guid`, `speed_type`, `speed_rate`) VALUES
(1583281828359, @CGUID+9, 0, 0.666668);

INSERT INTO `creature_movement_server` (`unixtimems`, `guid`, `point`, `move_time`, `spline_flags`, `spline_count`, `start_position_x`, `start_position_y`, `start_position_z`, `end_position_x`, `end_position_y`, `end_position_z`, `orientation`) VALUES
(1583281826343, @CGUID+8, 1, 0, 0, 0, -10662.09, 1130.827, 34.19674, 0, 0, 0, 2.513274), -- 6670
(1583281825937, @CGUID+13, 1, 3312, 2432696320, 1, -10601.13, 954.5218, 37.53686, -10600, 962.5, 35.84301, 100), -- 547
(1583281828359, @CGUID+13, 2, 0, 0, 0, -10600.31, 960.3052, 36.03161, 0, 0, 0, 100); -- 547


INSERT INTO `creature_movement_server_combat` (`unixtimems`, `guid`, `point`, `move_time`, `spline_flags`, `spline_count`, `start_position_x`, `start_position_y`, `start_position_z`, `end_position_x`, `end_position_y`, `end_position_z`, `orientation`) VALUES
(1583281819984, @CGUID+9, 1, 4909, 2432696320, 8, -10658.95, 1124.188, 34.19674, -10649.48, 1116.965, 35.63237, 100), -- 842
(1583281819984, @CGUID+12, 1, 3989, 2432696320, 5, -10653.21, 1130.438, 34.19574, -10658.75, 1134.619, 34.19674, 100), -- 6670
(1583281819984, @CGUID+8, 1, 7095, 2432696320, 7, -10661.11, 1115.039, 34.19674, -10662.09, 1130.827, 34.19674, 100), -- 6670
(1583281825250, @CGUID+13, 1, 8494, 2432696320, 13, -10600.92, 951.6986, 38.54507, -10601.13, 954.5218, 37.53686, 100); -- 547

INSERT INTO `creature_movement_server_combat_spline` (`guid`, `parent_point`, `spline_point`, `position_x`, `position_y`, `position_z`) VALUES
(@CGUID+9, 1, 1, -10661.06, 1126.159, 34.19674), -- 842
(@CGUID+9, 1, 2, -10658.95, 1124.188, 34.19674), -- 842
(@CGUID+9, 1, 3, -10656.83, 1122.216, 34.19674), -- 842
(@CGUID+9, 1, 4, -10656, 1121.438, 34.74628), -- 842
(@CGUID+9, 1, 5, -10654.48, 1120.391, 35.64084), -- 842
(@CGUID+9, 1, 6, -10651.13, 1118.096, 35.62662), -- 842
(@CGUID+9, 1, 7, -10649.48, 1116.965, 35.63237), -- 842
(@CGUID+9, 1, 8, -10649.48, 1116.965, 35.63237), -- 842
(@CGUID+12, 1, 1, -10647.28, 1125.957, 34.19578), -- 6670
(@CGUID+12, 1, 2, -10650.79, 1128.61, 34.19576), -- 6670
(@CGUID+12, 1, 3, -10654.3, 1131.262, 34.19574), -- 6670
(@CGUID+12, 1, 4, -10658.75, 1134.619, 34.19674), -- 6670
(@CGUID+12, 1, 5, -10658.75, 1134.619, 34.19674), -- 6670
(@CGUID+8, 1, 1, -10661.51, 1112.394, 34.19674), -- 6670
(@CGUID+8, 1, 2, -10661.28, 1113.16, 34.19674), -- 6670
(@CGUID+8, 1, 3, -10661.04, 1113.926, 34.19674), -- 6670
(@CGUID+8, 1, 4, -10661.41, 1119.873, 34.19674), -- 6670
(@CGUID+8, 1, 5, -10661.9, 1127.84, 34.19674), -- 6670
(@CGUID+8, 1, 6, -10662.09, 1130.827, 34.19674), -- 6670
(@CGUID+8, 1, 7, -10662.09, 1130.827, 34.19674), -- 6670
(@CGUID+13, 1, 1, -10599.21, 928.8047, 41.20321), -- 547
(@CGUID+13, 1, 2, -10599.58, 933.79, 40.95321), -- 547
(@CGUID+13, 1, 3, -10599.96, 938.7754, 40.70321), -- 547
(@CGUID+13, 1, 4, -10600.18, 941.7666, 40.53051), -- 547
(@CGUID+13, 1, 5, -10600.33, 943.7607, 40.15551), -- 547
(@CGUID+13, 1, 6, -10600.55, 946.752, 39.90551), -- 547
(@CGUID+13, 1, 7, -10600.7, 948.7461, 39.40551), -- 547
(@CGUID+13, 1, 8, -10600.85, 950.7402, 38.90551), -- 547
(@CGUID+13, 1, 9, -10600.92, 951.7373, 38.53051), -- 547
(@CGUID+13, 1, 10, -10600.99, 952.7344, 38.28051), -- 547
(@CGUID+13, 1, 11, -10601.07, 953.7314, 37.78051), -- 547
(@CGUID+13, 1, 12, -10601.13, 954.5218, 37.53686), -- 547
(@CGUID+13, 1, 13, -10601.13, 954.5218, 37.53686); -- 547


DELETE FROM `gameobject` WHERE `guid` BETWEEN @OGUID+0 AND @OGUID+3;
INSERT INTO `gameobject` (`guid`, `id`, `map`, `zone_id`, `area_id`, `position_x`, `position_y`, `position_z`, `orientation`, `rotation0`, `rotation1`, `rotation2`, `rotation3`, `is_temporary`, `creator_guid`, `creator_id`, `creator_type`, `display_id`, `level`, `faction`, `flags`, `dynamic_flags`, `path_progress`, `state`, `type`, `artkit`, `custom_param`, `sniff_build`) VALUES
(@OGUID+3, 130668, 0, 40, 108, -10651.63, 1106.913, 33.60647, 2.347464, 0, 0, 0.9222002, 0.3867128, 0, 0, 0, '', 306, 0, 0, 0, 0, 65535, 1, 8, 0, 0, 33526),
(@OGUID+1, 1843, 0, 40, 108, -10653.53, 1003.773, 32.7887, 2.609261, 0, 0, 0.9647865, 0.2630341, 0, 0, 0, '', 192, 0, 0, 0, 0, 65535, 1, 8, 0, 0, 33526),
(@OGUID+2, 130667, 0, 40, 108, -10650.1, 1104.901, 33.62935, 2.792518, 0, 0, 0.984807, 0.1736523, 0, 0, 0, '', 166, 0, 0, 0, 0, 65535, 1, 8, 0, 0, 33526);

INSERT INTO `gameobject_create1_time` (`unixtimems`, `guid`, `map`, `position_x`, `position_y`, `position_z`, `orientation`) VALUES
(1583281819984, @OGUID+3, 0, -10651.63, 1106.913, 33.60647, 2.347464),
(1583281819984, @OGUID+1, 0, -10653.53, 1003.773, 32.7887, 2.609261),
(1583281819984, @OGUID+2, 0, -10650.1, 1104.901, 33.62935, 2.792518);


INSERT INTO `spell_cast_start` (`unixtimems`, `caster_guid`, `caster_id`, `caster_type`, `caster_unit_guid`, `caster_unit_id`, `caster_unit_type`, `spell_id`, `visual_id`, `cast_time`, `cast_flags`, `cast_flags_ex`, `ammo_display_id`, `ammo_inventory_type`, `target_guid`, `target_id`, `target_type`) VALUES
(1583281819984, @PGUID+1, 0, 'Player', @PGUID+1, 0, 'Player', 836, 236955, 0, 2, 0, 0, 0, 0, 0, '');

INSERT INTO `spell_cast_go` (`unixtimems`, `caster_guid`, `caster_id`, `caster_type`, `caster_unit_guid`, `caster_unit_id`, `caster_unit_type`, `spell_id`, `visual_id`, `cast_flags`, `cast_flags_ex`, `ammo_display_id`, `ammo_inventory_type`, `main_target_guid`, `main_target_id`, `main_target_type`, `hit_targets_count`, `hit_targets_list_id`, `miss_targets_count`, `miss_targets_list_id`, `src_position_id`, `dst_position_id`, `orientation`) VALUES
(1583281819984, @PGUID+1, 0, 'Player', @PGUID+1, 0, 'Player', 836, 236955, 256, 16, 0, 0, 0, 0, '', 1, 1, 0, 0, 0, 0, 0);

INSERT INTO `spell_cast_go_target` (`list_id`, `target_guid`, `target_id`, `target_type`) VALUES
(1, @PGUID+1, 0, 'Player');


